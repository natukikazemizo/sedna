#!BPY
# -*- coding: UTF-8 -*-
# Log
#
# 2017.07.17 Natukikazemizo


def start(pyName):
    print(pyName + " START")

def end(pyName):
    print(pyName + " END")

